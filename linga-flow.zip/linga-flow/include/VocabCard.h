#pragma once
#include <string>
#include <ctime>

// Represents a single Spanish vocabulary flashcard
// Stores all SM-2 algorithm state alongside word data
struct VocabCard {
    std::string spanish;       // Spanish word
    std::string english;       // English translation
    std::string audioFile;     // Path to audio clip

    // SM-2 algorithm fields
    int repetitions   = 0;     // Number of successful reviews
    double easiness   = 2.5;   // Easiness factor (min 1.3)
    int interval      = 1;     // Days until next review
    time_t nextReview = 0;     // Unix timestamp of next review

    VocabCard() { nextReview = std::time(nullptr); }

    VocabCard(const std::string& sp, const std::string& en, const std::string& audio)
        : spanish(sp), english(en), audioFile(audio) {
        nextReview = std::time(nullptr);
    }

    // Comparator for priority queue: earlier review date = higher priority
    bool operator<(const VocabCard& other) const {
        return nextReview < other.nextReview;
    }
};
