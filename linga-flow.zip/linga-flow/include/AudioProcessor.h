#pragma once
#include <string>
#include <iostream>
#include <fstream>
#include <cstdlib>
#include <stdexcept>

// AudioProcessor handles playback of vocabulary word audio clips
// Uses platform-native audio commands; WAV files are stored in /audio/
class AudioProcessor {
public:
    // Play a .wav audio file for a vocab word
    // Supports macOS (afplay), Linux (aplay), and Windows (PowerShell)
    static void play(const std::string& filepath) {
        if (!fileExists(filepath)) {
            std::cerr << "[AudioProcessor] File not found: " << filepath << "\n";
            return;
        }

        std::string cmd;

#if defined(__APPLE__)
        cmd = "afplay \"" + filepath + "\" 2>/dev/null";
#elif defined(__linux__)
        cmd = "aplay \"" + filepath + "\" 2>/dev/null";
#elif defined(_WIN32)
        cmd = "powershell -c (New-Object Media.SoundPlayer '" + filepath + "').PlaySync()";
#else
        std::cerr << "[AudioProcessor] Platform not supported for audio playback.\n";
        return;
#endif
        int result = std::system(cmd.c_str());
        if (result != 0)
            std::cerr << "[AudioProcessor] Playback failed for: " << filepath << "\n";
    }

    // Load raw PCM samples from a WAV file into a buffer (for future processing)
    static std::vector<char> loadWAV(const std::string& filepath) {
        std::ifstream file(filepath, std::ios::binary);
        if (!file.is_open())
            throw std::runtime_error("Cannot open WAV file: " + filepath);

        // Read entire file into buffer
        return std::vector<char>(
            std::istreambuf_iterator<char>(file),
            std::istreambuf_iterator<char>()
        );
    }

private:
    static bool fileExists(const std::string& path) {
        std::ifstream f(path);
        return f.good();
    }
};
