#pragma once
#include "VocabCard.h"

// Implementation of the SM-2 Spaced Repetition algorithm
// Originally developed by Piotr Wozniak (SuperMemo, 1987)
// Quality scale: 0-5 (0-1 = fail, 2 = barely, 3 = correct w/ effort, 4 = correct, 5 = perfect)
class SM2 {
public:
    // Apply SM-2 update to a card based on recall quality (0-5)
    static void update(VocabCard& card, int quality) {
        if (quality < 0 || quality > 5)
            throw std::invalid_argument("Quality must be between 0 and 5");

        if (quality >= 3) {
            // Successful recall - advance interval
            if (card.repetitions == 0)
                card.interval = 1;
            else if (card.repetitions == 1)
                card.interval = 6;
            else
                card.interval = static_cast<int>(card.interval * card.easiness);

            card.repetitions++;
        } else {
            // Failed recall - reset to beginning
            card.repetitions = 0;
            card.interval = 1;
        }

        // Update easiness factor
        card.easiness += 0.1 - (5 - quality) * (0.08 + (5 - quality) * 0.02);
        if (card.easiness < 1.3) card.easiness = 1.3;  // Minimum EF

        // Schedule next review
        card.nextReview = std::time(nullptr) + (card.interval * 86400); // seconds in a day
    }

    // Returns whether a card is due for review right now
    static bool isDue(const VocabCard& card) {
        return std::time(nullptr) >= card.nextReview;
    }
};
