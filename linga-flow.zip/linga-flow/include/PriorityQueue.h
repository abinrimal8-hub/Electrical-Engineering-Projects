#pragma once
#include <vector>
#include <stdexcept>

// Custom min-heap priority queue for SRS scheduling
// Orders vocab cards by next review date (earliest = highest priority)
template <typename T, typename Compare = std::less<T>>
class PriorityQueue {
public:
    PriorityQueue() = default;

    void push(const T& item) {
        heap.push_back(item);
        bubbleUp(heap.size() - 1);
    }

    T pop() {
        if (isEmpty()) throw std::runtime_error("PriorityQueue is empty");
        T top = heap[0];
        heap[0] = heap.back();
        heap.pop_back();
        if (!heap.empty()) sinkDown(0);
        return top;
    }

    const T& peek() const {
        if (isEmpty()) throw std::runtime_error("PriorityQueue is empty");
        return heap[0];
    }

    bool isEmpty() const { return heap.empty(); }
    size_t size() const { return heap.size(); }

private:
    std::vector<T> heap;
    Compare comp;

    void bubbleUp(int index) {
        while (index > 0) {
            int parent = (index - 1) / 2;
            if (comp(heap[parent], heap[index])) break;
            std::swap(heap[parent], heap[index]);
            index = parent;
        }
    }

    void sinkDown(int index) {
        int size = heap.size();
        while (true) {
            int left = 2 * index + 1;
            int right = 2 * index + 2;
            int smallest = index;
            if (left < size && comp(heap[left], heap[smallest])) smallest = left;
            if (right < size && comp(heap[right], heap[smallest])) smallest = right;
            if (smallest == index) break;
            std::swap(heap[index], heap[smallest]);
            index = smallest;
        }
    }
};
