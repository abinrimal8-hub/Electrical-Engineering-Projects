#include <iostream>
#include <vector>
#include <string>
#include <limits>
#include "../include/VocabCard.h"
#include "../include/SM2.h"
#include "../include/PriorityQueue.h"
#include "../include/AudioProcessor.h"

// ─── Spanish Vocabulary Dataset ──────────────────────────────────────────────
std::vector<VocabCard> loadSpanishVocab() {
    return {
        VocabCard("hola",         "hello",        "audio/hola.wav"),
        VocabCard("gracias",      "thank you",    "audio/gracias.wav"),
        VocabCard("perro",        "dog",           "audio/perro.wav"),
        VocabCard("gato",         "cat",           "audio/gato.wav"),
        VocabCard("casa",         "house",         "audio/casa.wav"),
        VocabCard("libro",        "book",          "audio/libro.wav"),
        VocabCard("agua",         "water",         "audio/agua.wav"),
        VocabCard("amigo",        "friend",        "audio/amigo.wav"),
        VocabCard("escuela",      "school",        "audio/escuela.wav"),
        VocabCard("tiempo",       "time / weather","audio/tiempo.wav"),
        VocabCard("comer",        "to eat",        "audio/comer.wav"),
        VocabCard("hablar",       "to speak",      "audio/hablar.wav"),
        VocabCard("correr",       "to run",        "audio/correr.wav"),
        VocabCard("dormir",       "to sleep",      "audio/dormir.wav"),
        VocabCard("ciudad",       "city",          "audio/ciudad.wav"),
    };
}

// ─── Display helpers ──────────────────────────────────────────────────────────
void printHeader() {
    std::cout << "\n";
    std::cout << "  ██╗     ██╗███╗   ██╗ ██████╗  █████╗     ███████╗██╗      ██████╗ ██╗    ██╗\n";
    std::cout << "  ██║     ██║████╗  ██║██╔════╝ ██╔══██╗    ██╔════╝██║     ██╔═══██╗██║    ██║\n";
    std::cout << "  ██║     ██║██╔██╗ ██║██║  ███╗███████║    █████╗  ██║     ██║   ██║██║ █╗ ██║\n";
    std::cout << "  ██║     ██║██║╚██╗██║██║   ██║██╔══██║    ██╔══╝  ██║     ██║   ██║██║███╗██║\n";
    std::cout << "  ███████╗██║██║ ╚████║╚██████╔╝██║  ██║    ██║     ███████╗╚██████╔╝╚███╔███╔╝\n";
    std::cout << "  ╚══════╝╚═╝╚═╝  ╚═══╝ ╚═════╝ ╚═╝  ╚═╝    ╚═╝     ╚══════╝ ╚═════╝  ╚══╝╚══╝ \n";
    std::cout << "\n  Spanish Vocabulary Trainer  |  Powered by SM-2 Spaced Repetition\n";
    std::cout << "  ─────────────────────────────────────────────────────────────────\n\n";
}

int getQualityInput() {
    int q = -1;
    while (q < 0 || q > 5) {
        std::cout << "  Rate your recall  [0 = blackout | 3 = correct | 5 = perfect]: ";
        if (!(std::cin >> q)) {
            std::cin.clear();
            std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
            q = -1;
        }
    }
    return q;
}

// ─── Main session loop ────────────────────────────────────────────────────────
int main() {
    printHeader();

    // Load vocab and push all cards into the priority queue
    auto vocab = loadSpanishVocab();
    PriorityQueue<VocabCard> reviewQueue;
    for (auto& card : vocab)
        reviewQueue.push(card);

    std::cout << "  Loaded " << reviewQueue.size() << " Spanish vocabulary cards.\n";
    std::cout << "  Cards are ordered by next review date (due first).\n\n";

    int sessionLimit = 10;  // Review up to 10 cards per session
    int reviewed = 0;

    while (!reviewQueue.isEmpty() && reviewed < sessionLimit) {
        VocabCard card = reviewQueue.pop();

        std::cout << "  ┌─────────────────────────────────────┐\n";
        std::cout << "  │  Card " << (reviewed + 1) << " of " << sessionLimit << "\n";
        std::cout << "  │  Spanish:  " << card.spanish << "\n";
        std::cout << "  │  [Press ENTER to hear audio + reveal]\n";
        std::cout << "  └─────────────────────────────────────┘\n";

        std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
        std::cin.get();

        // Play audio clip
        AudioProcessor::play(card.audioFile);

        std::cout << "  English:   " << card.english << "\n\n";

        // Get recall quality and update SM-2 state
        int quality = getQualityInput();
        SM2::update(card, quality);

        // Reschedule card back into queue
        reviewQueue.push(card);

        // Show next review interval
        std::cout << "  → Next review in " << card.interval << " day(s)\n\n";
        reviewed++;
    }

    std::cout << "\n  Session complete! Reviewed " << reviewed << " cards.\n";
    std::cout << "  Keep it up — consistency is everything.\n\n";
    return 0;
}
