# Linga Flow — Spanish Vocabulary Trainer

A C++ spaced repetition vocabulary trainer built around the **SM-2 algorithm**, designed to maximize long-term retention of Spanish vocabulary through scientifically-spaced review intervals and audio reinforcement.

---

## Features

- **SM-2 Spaced Repetition Algorithm** — the same algorithm powering Anki, adapted from Piotr Wozniak's SuperMemo research
- **Custom Min-Heap Priority Queue** — cards are dynamically ordered by next review date with no external libraries
- **Audio Playback Engine** — plays native `.wav` audio clips for each vocabulary word (supports macOS, Linux, Windows)
- **Session-based review loop** — review due cards, rate your recall (0–5), and get automatically rescheduled

---

## Project Structure

```
linga-flow/
├── include/
│   ├── VocabCard.h        # Core flashcard data structure + SM-2 state
│   ├── SM2.h              # SM-2 algorithm implementation
│   ├── PriorityQueue.h    # Custom templated min-heap priority queue
│   └── AudioProcessor.h   # Cross-platform WAV audio playback
├── src/
│   └── main.cpp           # Session loop + Spanish vocab dataset
├── audio/
│   └── *.wav              # Audio clips (add your own .wav files here)
├── CMakeLists.txt
└── README.md
```

---

## Build & Run

**Requirements:** C++17, CMake 3.14+

```bash
git clone https://github.com/abinrimal8/linga-flow.git
cd linga-flow
mkdir build && cd build
cmake ..
make
./linga_flow
```

---

## How SM-2 Works

Each card has an **easiness factor (EF)** starting at 2.5 and a **review interval** (in days). After each review you rate your recall 0–5:

| Rating | Meaning |
|--------|---------|
| 0–1 | Complete blackout / wrong |
| 2 | Wrong but answer felt familiar |
| 3 | Correct with significant effort |
| 4 | Correct with minor hesitation |
| 5 | Perfect recall |

If quality ≥ 3, the interval grows: `new_interval = old_interval × EF`. If quality < 3, the card resets to day 1. The EF adjusts after every review, so hard words get reviewed more frequently over time.

---

## Adding Audio Files

Drop `.wav` files into the `audio/` folder. File names must match the `audioFile` field in `main.cpp`:

```cpp
VocabCard("hola", "hello", "audio/hola.wav")
```

Free Spanish audio clips can be generated at [forvo.com](https://forvo.com) or [Google TTS](https://cloud.google.com/text-to-speech).

---

## Built By

Abin Rimal — Virginia Tech ECE  
Part of the Linga Flow language learning platform
