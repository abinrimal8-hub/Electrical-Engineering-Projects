# FSAE Suspension Strain Gauge — Force Sensor System

Firmware for a real-time suspension force sensing system deployed on a Formula SAE competition vehicle. A strain gauge is bonded to the **pushrod suspension member** and reads micro-scale resistance changes under load via a **Wheatstone bridge circuit** amplified by an **INA128 precision instrumentation amplifier**, all routed through a custom **Altium Designer PCB**.

---

## Hardware Overview

```
Pushrod (under load)
       │
  Strain Gauge (bonded to pushrod)
       │ ΔR (micro-scale resistance change)
  Wheatstone Bridge Circuit
       │ V_differential (mV-level signal)
  INA128 Instrumentation Amplifier  ←── Gain set by Rg resistor
       │ V_out (amplified, clean signal)
  Microcontroller ADC (10-bit)
       │
  Serial Data Logger (CSV @ 20 Hz)
```

---

## Why INA128?

The bridge differential output is in the **millivolt range** — too small and noisy for a direct ADC read. The INA128 was selected over a standard op-amp for:

- **High CMRR** (common-mode rejection ratio) — rejects electrical noise from the car
- **Single resistor gain setting** — `G = 1 + (50kΩ / Rg)`, easy to tune
- **Low input offset voltage** — critical for accurate low-force readings
- **Rail-to-rail output** — maximizes ADC dynamic range

---

## Project Structure

```
strain-gauge/
├── include/
│   ├── StrainGauge.h      # ADC reading + INA128 voltage conversion
│   └── Calibration.h      # Two-point linear force calibration
├── src/
│   └── main.cpp           # Main data logging loop (20 Hz, CSV output)
├── pcb/
│   └── Pitot_Tube.PcbDoc  # Altium Designer PCB file
└── README.md
```

---

## Calibration Procedure

1. Mount the sensor with **zero load** on the pushrod
2. Record the bridge voltage output → set as `ZERO_LOAD_VOLTAGE`
3. Apply a **known force** (e.g., hang a calibrated weight)
4. Record the bridge voltage → set as `REF_LOAD_VOLTAGE` and `REF_FORCE_NEWTONS`
5. Flash firmware — sensor is ready

---

## Serial Output Format

Data is logged at **20 Hz** in CSV format for easy plotting:

```
Timestamp(ms), Bridge_Voltage(mV), Force(N), Status
────────────────────────────────────────────────────
1023, 2.4812, 0.00, OK
1073, 3.1204, 98.23, OK
1123, 5.8821, 533.17, OK
```

Import directly into MATLAB or Excel for post-session analysis.

---

## Build & Flash

Developed for Arduino-compatible microcontrollers (Uno/Nano). Open in **Arduino IDE** or **PlatformIO**:

```bash
# PlatformIO
pio run --target upload
```

---

## PCB

The PCB was designed in **Altium Designer**, incorporating the Wheatstone bridge circuit, INA128 amplifier stage, and decoupling capacitors. The `.PcbDoc` file is included in `/pcb/`.

---

## Built By

Abin Rimal — Virginia Tech ECE | EPT / FSAE Subteam
