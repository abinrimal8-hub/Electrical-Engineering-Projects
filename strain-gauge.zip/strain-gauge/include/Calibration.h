#pragma once
#include <Arduino.h>

// Calibration.h
// Maps INA128 bridge voltage output to real force values (Newtons)
// Uses two-point linear calibration from known applied loads
// Calibration points collected by applying known weights to the pushrod

class Calibration {
public:
    // Calibration point 1: zero load (tare)
    float v_zero  = 0.0f;   // Bridge voltage (mV) at 0N
    float f_zero  = 0.0f;   // Force (N)

    // Calibration point 2: known reference load
    float v_ref   = 0.0f;   // Bridge voltage (mV) at reference load
    float f_ref   = 0.0f;   // Reference force (N)

    bool isCalibrated = false;

    // Set calibration points from known load measurements
    void calibrate(float voltageAtZero, float voltageAtRef, float refForce) {
        v_zero = voltageAtZero;
        f_zero = 0.0f;
        v_ref  = voltageAtRef;
        f_ref  = refForce;
        isCalibrated = true;

        Serial.println("[Calibration] Calibration set:");
        Serial.print("  Zero load voltage : "); Serial.print(v_zero, 4); Serial.println(" mV");
        Serial.print("  Ref load voltage  : "); Serial.print(v_ref, 4);  Serial.println(" mV");
        Serial.print("  Ref force         : "); Serial.print(f_ref, 2);  Serial.println(" N");
        Serial.print("  Sensitivity       : "); Serial.print(getSensitivity(), 6); Serial.println(" N/mV");
    }

    // Convert bridge voltage (mV) to force (N) via linear interpolation
    float voltageToForce(float voltage_mV) {
        if (!isCalibrated) return 0.0f;
        return f_zero + (voltage_mV - v_zero) * getSensitivity();
    }

    // Tare: set current reading as zero reference
    void tare(float currentVoltage_mV) {
        v_zero = currentVoltage_mV;
        Serial.print("[Calibration] Tare set at: ");
        Serial.print(v_zero, 4);
        Serial.println(" mV");
    }

private:
    // Sensitivity in N/mV
    float getSensitivity() {
        if (v_ref == v_zero) return 0.0f;
        return (f_ref - f_zero) / (v_ref - v_zero);
    }
};
