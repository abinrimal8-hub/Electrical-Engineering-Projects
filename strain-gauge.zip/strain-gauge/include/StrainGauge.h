#pragma once
#include <Arduino.h>

// StrainGauge.h
// Reads the INA128 instrumentation amplifier output via microcontroller ADC
// The INA128 amplifies the Wheatstone bridge differential output
// Bridge is bonded to FSAE pushrod; resistance change = strain = force

class StrainGauge {
public:
    // ADC configuration
    static constexpr int    ADC_PIN        = A0;     // Analog pin connected to INA128 output
    static constexpr float  VCC            = 5.0f;   // Supply voltage (V)
    static constexpr int    ADC_RESOLUTION = 1024;   // 10-bit ADC (Arduino Uno/Nano)
    static constexpr int    NUM_SAMPLES    = 64;     // Samples to average per reading (noise reduction)

    // INA128 gain config
    // Gain = 1 + (50kΩ / Rg)
    // Rg selected based on expected bridge output range
    static constexpr float  GAIN_RESISTOR  = 499.0f;  // Rg in ohms
    static constexpr float  INA128_GAIN    = 1.0f + (50000.0f / GAIN_RESISTOR); // ~101.2

    StrainGauge() {}

    void begin() {
        pinMode(ADC_PIN, INPUT);
    }

    // Read averaged ADC value (reduces noise)
    int readRaw() {
        long sum = 0;
        for (int i = 0; i < NUM_SAMPLES; i++) {
            sum += analogRead(ADC_PIN);
            delayMicroseconds(100);
        }
        return static_cast<int>(sum / NUM_SAMPLES);
    }

    // Convert raw ADC to voltage at INA128 output (V)
    float readVoltage() {
        int raw = readRaw();
        return (raw / static_cast<float>(ADC_RESOLUTION)) * VCC;
    }

    // Convert INA128 output voltage back to bridge differential voltage (mV)
    // V_bridge = V_out / gain
    float readBridgeVoltage_mV() {
        float vOut = readVoltage();
        return (vOut / INA128_GAIN) * 1000.0f;
    }
};
