#include <Arduino.h>
#include "StrainGauge.h"
#include "Calibration.h"

// ─── Strain Gauge Force Sensor — FSAE Suspension Pushrod ─────────────────────
// Hardware: Wheatstone bridge + INA128 instrumentation amplifier + PCB (Altium)
// Measures suspension pushrod forces in real-time during vehicle testing
// Serial output at 115200 baud — log with Serial Monitor or data logger

StrainGauge gauge;
Calibration  cal;

// ─── Calibration constants (update after physical calibration) ────────────────
// These were determined by applying known weights to the pushrod
constexpr float ZERO_LOAD_VOLTAGE = 2.48f;   // mV at zero load (tare)
constexpr float REF_LOAD_VOLTAGE  = 8.73f;   // mV at reference load
constexpr float REF_FORCE_NEWTONS = 500.0f;  // Reference load in Newtons

// ─── Logging config ───────────────────────────────────────────────────────────
constexpr int   LOG_INTERVAL_MS   = 50;      // 20 Hz sample rate
constexpr float FORCE_ALERT_N     = 2000.0f; // Warn if force exceeds this threshold

void setup() {
    Serial.begin(115200);
    while (!Serial) {}

    Serial.println("================================================");
    Serial.println("  Linga Flow FSAE Strain Gauge Data Logger");
    Serial.println("  Wheatstone Bridge + INA128 + Altium PCB");
    Serial.println("================================================\n");

    gauge.begin();

    // Apply calibration
    cal.calibrate(ZERO_LOAD_VOLTAGE, REF_LOAD_VOLTAGE, REF_FORCE_NEWTONS);

    Serial.println("\n[System] Sensor ready. Logging at 20 Hz...");
    Serial.println("Timestamp(ms), Bridge_Voltage(mV), Force(N), Status");
    Serial.println("────────────────────────────────────────────────────");
}

void loop() {
    float bridgeVoltage = gauge.readBridgeVoltage_mV();
    float force         = cal.voltageToForce(bridgeVoltage);

    // Determine status
    String status = "OK";
    if (!cal.isCalibrated)      status = "UNCALIBRATED";
    else if (force > FORCE_ALERT_N) status = "OVERLOAD WARNING";
    else if (force < -100.0f)   status = "CHECK WIRING";

    // CSV output for easy data logging / plotting
    Serial.print(millis());
    Serial.print(", ");
    Serial.print(bridgeVoltage, 4);
    Serial.print(", ");
    Serial.print(force, 2);
    Serial.print(", ");
    Serial.println(status);

    delay(LOG_INTERVAL_MS);
}
